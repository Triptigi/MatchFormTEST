﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MatchForm.Models
{
    public class Match
    {
        [Key]
        public int MatchId { get; set; }
        [Required]
        [Display(Name = "Match Name")]
        public string Name { get; set; }
        [Required]
        [Display(Name = "Match Date")]

        public DateTime Date { get; set; }
        //[Required]
        public TimeSpan StartTime { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string Team1 { get; set; }
        [Required]
        public string Team2 { get; set; }
        //
        public ICollection<Player> Player { get; set; }


    }
}
