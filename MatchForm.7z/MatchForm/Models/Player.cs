﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MatchForm.Models
{
    public class Player
    {
        [Key]
        public int PlayerId { get; set; }
        [Required]
        public string Name { get; set; }
        public string Type { get; set; }
        [Required]
        public int Position { get; set; }
        [Required]
        public string Team { get; set; }
        public int MatchId { get; set; }
        public Match Match { get; set; }
    }
}
