﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MatchForm.Data.Migrations
{
    public partial class init3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Match_Player_PlayerId",
                table: "Match");

            migrationBuilder.DropIndex(
                name: "IX_Match_PlayerId",
                table: "Match");

            migrationBuilder.DropColumn(
                name: "PlayerId",
                table: "Match");

            migrationBuilder.AddColumn<int>(
                name: "MatchId",
                table: "Player",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Type",
                table: "Player",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Player_MatchId",
                table: "Player",
                column: "MatchId");

            migrationBuilder.AddForeignKey(
                name: "FK_Player_Match_MatchId",
                table: "Player",
                column: "MatchId",
                principalTable: "Match",
                principalColumn: "MatchId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Player_Match_MatchId",
                table: "Player");

            migrationBuilder.DropIndex(
                name: "IX_Player_MatchId",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "MatchId",
                table: "Player");

            migrationBuilder.DropColumn(
                name: "Type",
                table: "Player");

            migrationBuilder.AddColumn<int>(
                name: "PlayerId",
                table: "Match",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Match_PlayerId",
                table: "Match",
                column: "PlayerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Match_Player_PlayerId",
                table: "Match",
                column: "PlayerId",
                principalTable: "Player",
                principalColumn: "PlayerId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
