﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MatchForm.Data.Migrations
{
    public partial class Init1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Team1",
                table: "Match",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Team2",
                table: "Match",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Team1",
                table: "Match");

            migrationBuilder.DropColumn(
                name: "Team2",
                table: "Match");
        }
    }
}
